---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://repo.or.cz/llf.git",
    description = "A LaTeX reformatter / beautifier.",
  },
  command = "llf",
  stdin = true,
}
