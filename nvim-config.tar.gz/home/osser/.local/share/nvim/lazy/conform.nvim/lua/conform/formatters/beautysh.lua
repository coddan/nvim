---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/lovesegfault/beautysh",
    description = "A Bash beautifier for the masses.",
  },
  command = "beautysh",
  args = { "-" },
}
