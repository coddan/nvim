---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://kamadorueda.com/alejandra/",
    description = "The Uncompromising Nix Code Formatter.",
  },
  command = "alejandra",
}
