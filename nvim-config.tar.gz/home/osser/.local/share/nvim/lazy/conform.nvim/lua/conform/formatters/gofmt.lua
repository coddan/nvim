---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://pkg.go.dev/cmd/gofmt",
    description = "Formats go programs.",
  },
  command = "gofmt",
}
