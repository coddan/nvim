## Tokyonight for [termux](https://termux.dev/)

### Usage

1. Choose your flavour.
2. Copy the contents of `tokyonight_flavour.properties` to `~/.termux/colors.properties`.
3. Then run `termux-reload-settings` or restart termux.
